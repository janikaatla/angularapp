import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';

import { AppRoutingModule, routes } from './app-routing.module';
import { AppComponent } from './app.component';
import {TabContentComponent} from './tabconfig/TabContentComponent';
import {ContentContainerDirective} from './tabconfig/ContentContainerDirective';
import {DefaultLayoutComponent} from './sidebar/default-layout/default-layout.component';
import { AgGridSearchComponent } from './ag-grid-search/ag-grid-search.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import { TabComponent } from './tab/tab.component';
import {MatOptionModule} from '@angular/material/core';
import { MatGridComponent } from './mat-grid/mat-grid.component';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import {AgGridModule} from 'ag-grid-angular';
import {RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';


// Loader
// import {SpinnerOverlayService} from './service/spinner-overlay.service';
// import { LoadingComponent } from './loading/loading.component';
// import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

const APP_CONTAINERS = [
  DefaultLayoutComponent
];




@NgModule({
  declarations: [
    AppComponent,
    ...APP_CONTAINERS,
    TabContentComponent,
    ContentContainerDirective,
    DefaultLayoutComponent,
    AgGridSearchComponent,
    TabComponent,
    MatGridComponent,
    // LoadingComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatIconModule,
    MatOptionModule,
    MatTabsModule,
    MatTableModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    AgGridModule.withComponents([]),
  ],
  providers: [],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  // entryComponents: [LoadingComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
