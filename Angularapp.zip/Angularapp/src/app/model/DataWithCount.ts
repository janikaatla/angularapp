import {ClientInfo} from './ClientInfo';

export class DataWithCount {
  public totalCount: number;
  public clientInfoList: ClientInfo[];

}
