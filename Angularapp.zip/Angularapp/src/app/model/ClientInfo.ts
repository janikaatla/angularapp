export class ClientInfo {
  private name: string;
  private email: string;
  private mobile: string;
  private gender: string;
}
