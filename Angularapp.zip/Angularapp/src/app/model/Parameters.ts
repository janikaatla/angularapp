export class Parameters {
  public pageNo: number;
  public pageSize: number;
  public startNo: number;
  public endNo: number;
  public sortingColumn: string;
  public sortingOrder: string;

}
