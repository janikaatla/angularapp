import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {TabService} from '../../tabconfig/tab.service';
import {AppComponent} from '../../app.component';
import {Tab} from '../../tabconfig/Tab';
import {AgGridSearchComponent} from '../../ag-grid-search/ag-grid-search.component';
import { MatGridComponent } from 'src/app/mat-grid/mat-grid.component';

@Component({
  selector: 'app-default-layout',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss']
})
export class DefaultLayoutComponent implements OnInit {
  tabs = [];
  activeTabUrl;
  currentUser: string;
  showFiller = false;
  constructor(private router: Router, private tabService: TabService) { }

  ngOnInit() {
    this.currentUser = 'Test User';
  }

  displayAGGridComp() {
    const tab = new Tab(AgGridSearchComponent, 'AG-Grid Search', { parent: 'TabComponent' });
    tab.id = 0;
    this.tabService.addTab(tab);
  }
  displayMATGridComp() {
    const tab = new Tab(MatGridComponent, 'Mat-Grid Search', { parent: 'TabComponent' });
    tab.id = 0;
    this.tabService.addTab(tab);
  }
  logOut() {
    // code
  }

}
