import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mat-grid',
  templateUrl: './mat-grid.component.html',
  styleUrls: ['./mat-grid.component.scss']
})
export class MatGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
