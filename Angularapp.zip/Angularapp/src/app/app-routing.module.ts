import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DefaultLayoutComponent} from './sidebar/default-layout/default-layout.component';
import {AgGridSearchComponent} from './ag-grid-search/ag-grid-search.component';
import {TabComponent} from './tab/tab.component';
import { MatGridComponent } from 'src/app/mat-grid/mat-grid.component';


export const routes: Routes = [
  {
    path: 'layoutComponent',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home',
    },
    children: [
      {
        path: 'tab',
        component: TabComponent
      },
      {
        path: 'Ag-Grid',
        component: AgGridSearchComponent
      },
      {
        path: 'Mat-Grid',
        component: MatGridComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
