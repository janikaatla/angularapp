export interface SkeletonComponent {
  data: any;
}
