import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {Tab} from './Tab';


@Injectable({
  providedIn: 'root',
})
export class TabService {
  private exist = false;
  private currentTabIndex: number;
  public tabs: Tab[] = [];
  public tabSub = new BehaviorSubject<Tab[]>(this.tabs);
  public removeTab(index: number) {
    this.tabs.splice(index, 1);
    if (this.tabs.length > 0) {
        this.tabs[this.tabs.length - 1].active = true;
        this.currentTabIndex = this.tabs.length - 1;
        this.tabSub.next(this.tabs);
    }

  }
  public addTab(tab: Tab) {
    this.exist = false;
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.tabs.length; i++) {
      if (this.tabs[i].active === true) {
        this.tabs[i].active = false;
      }
      if (this.tabs[i].title === tab.title) {
        this.exist = true;
      }
    }
    console.log('this.exist : ' + this.exist);
    if (!this.exist) {
      // tslint:disable-next-line:prefer-for-of
      tab.id = this.tabs.length + 1;
      tab.active = true;
      console.log('tab.active : ' + tab.active);
      console.log('tab.title : ' + tab.title);
      this.tabs.push(tab);
      this.tabSub.next(this.tabs);
    } else {
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < this.tabs.length; i++) {
        if (this.tabs[i].title === tab.title) {
          this.tabs[i].active = true;
        }
      }
      this.tabSub.next(this.tabs);
    }
  }

  public isEmptyObject(obj) {
    return (obj && (Object.keys(obj).length === 0));
  }

  public isEmpty(obj) {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        return false;
      }
    }
    return true;
  }
  public presentTabIndex(index) {
    this.currentTabIndex = index;
    for (let i = 0; i < this.tabs.length; i++) {
      if (i === this.currentTabIndex) {
        this.tabs[i].active = true;
      } else {
        this.tabs[i].active = false;
      }
    }
  }

  public getCurrentIndex() {
    return this.currentTabIndex;
  }

}
