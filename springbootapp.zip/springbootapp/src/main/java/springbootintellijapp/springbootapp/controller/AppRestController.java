package springbootintellijapp.springbootapp.controller;

// import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import springbootintellijapp.springbootapp.pojo.AppModel;
import springbootintellijapp.springbootapp.pojo.ClientInfo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin(origins="*", maxAge=3600)
public class AppRestController {

    @RequestMapping("/")
    public String welcome() {
        return "Welcome App";
    }

    @RequestMapping("/data")
    public List<AppModel> data(@RequestParam Integer startnum,@RequestParam Integer limit) {
        List<AppModel> appList=new ArrayList<AppModel>();
        Integer k=0;
        Integer n=limit+1;
        AppModel appModel=null;
        for (k=startnum;k<n;k++) {
            appModel = new AppModel();
            appModel.setId(k);
            appModel.setUniName("Name"+k);
            appModel.setDate(""+new Date().toString());
            appList.add(appModel);
        }
        System.out.println("list size :"+appList.size());
        return appList;
    }

    @GetMapping("/AGGriddata")
    public List<ClientInfo> agGridData() {// @RequestParam Integer startnum,@RequestParam Integer limit
        List<ClientInfo> appList=new ArrayList<ClientInfo>();
        Integer k=0;
        Integer n=20+1;
        ClientInfo appModel=null;
        for (k=0;k<n;k++) {
            appModel = new ClientInfo();
            appModel.setGender("Male");
            appModel.setName("Name"+k);
            appModel.setEmail("Name"+k+"@gmail.com");
            appModel.setMobile("900090009"+k);
            appList.add(appModel);
        }
        System.out.println("list size :"+appList.size());
        return appList;
    }
}

